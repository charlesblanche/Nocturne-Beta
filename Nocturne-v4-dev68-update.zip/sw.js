/* Versioned application shell only. Never read or delete character storage. */
const PREFIX='nocturne-shell:'+self.registration.scope+':';
const CACHE=PREFIX+'4.0.0-dev.68';
const ASSETS=['./','./index.html','./manifest.webmanifest','./icon.svg','./icon-192.png','./icon-512.png','./apple-touch-icon.png'];
const URLS=new Set(ASSETS.map(path=>new URL(path,self.registration.scope).href));
const INDEX=new URL('./index.html',self.registration.scope).href;
self.addEventListener('install',event=>{
 // An incomplete download must not replace a working release.
 event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll([...URLS])));
});
self.addEventListener('message',event=>{
 if(event.data?.type==='NOCTURNE_ACTIVATE_UPDATE')event.waitUntil(self.skipWaiting());
});
self.addEventListener('activate',event=>{
 event.waitUntil((async()=>{
  const keys=await caches.keys();
  await Promise.all(keys.filter(k=>k.startsWith(PREFIX)&&k!==CACHE).map(k=>caches.delete(k)));
  await self.clients.claim();
 })());
});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET')return;
 const url=new URL(req.url);
 if(!URLS.has(url.href))return;
 // Keep the shell version consistent until the next worker is installed and activated.
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE);
  const hit=await cache.match(req.mode==='navigate'?INDEX:req);
  if(hit)return hit;
  return fetch(req);
 })());
});
